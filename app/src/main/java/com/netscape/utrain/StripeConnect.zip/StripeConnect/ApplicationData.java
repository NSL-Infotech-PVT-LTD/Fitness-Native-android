package com.netscape.utrain.StripeConnect;

public class ApplicationData {
//    public static final String CLIENT_ID = "ca_GrNVCnvyWUDWYl1FtRiXWAj9iF4fGICg";
    //    public static final String CLIENT_ID = "ca_GrI5mZuu461MAwHob5Gd5gGFe1Ufiwu3";
        public static final String CLIENT_ID = "ca_GrI5lLrr9JZXHV6tiGHGp8LhPmo8iAJO";
//    public static final String SECRET_KEY = "sk_test_7EKtQo8N6TCr9eAB6soOJCgh005NCqOdcI";
    public static final String SECRET_KEY = "sk_test_K0xc0qyrTPfW8DA918NJRInu00ZPChh3gj";
    public static final String CALLBACK_URL = "http://18.222.149.116/pms/public/client/planinfo";
}
